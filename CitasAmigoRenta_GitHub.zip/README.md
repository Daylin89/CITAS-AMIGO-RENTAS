# Citas Amigo Renta — Android v1

Primera versión funcional: registro/edición local de citas, vendedores, estados, resumen y recordatorio 30 minutos antes.

## Abrir
1. Instala Android Studio.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle descargue el Android Gradle Plugin y compila el módulo `app`.

## Próxima fase
- Base de datos sincronizada para varios teléfonos.
- Usuarios/permisos.
- Calendario de Android para agendador y atendiente.
- Seguimientos independientes.
- Exportación `.xlsx`.
- Reportes por vendedor y filtros.
