# Citas Amigo Renta — Android v3.0

App del equipo de ventas: agendar y ver las citas del equipo, ver las habitaciones disponibles con sus fotos
(compartirlas con el cliente) y subir los enlaces de los anuncios publicados cada día. Abre la página /ci del
servidor amigorentacliente; cada vendedor entra con su nombre y su PIN (permiso «Solo app de Citas» en la App
Operativa). Todo llega directo a la app de Marketing y Ventas. Al instalarse encima de la versión 2.x, las citas
que estaban solo en el teléfono se suben una vez al servidor.
Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
