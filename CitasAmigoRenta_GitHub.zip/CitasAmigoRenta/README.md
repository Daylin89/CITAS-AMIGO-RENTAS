# Citas Amigo Renta — Android v2

Pantallas: Inicio (resumen del mes, citas de hoy, seguimientos pendientes, próximas citas),
Todas las citas (buscador y filtros por estado), Nueva/Editar cita, Detalle (llamar, WhatsApp,
mapa, agregar al calendario, cambiar estado, historial), Seguimientos con recordatorio,
Calendario, Reportes por vendedor con gráfica, Exportar a Excel (.csv) y Vendedores.

Se compila con GitHub Actions (archivo .github/workflows/compilar-apk.yml del repositorio).
La firma es fija (app/amigo.keystore), así las próximas versiones se instalan encima sin perder datos.

Pendiente para una fase futura: base de datos compartida entre varios teléfonos y usuarios con contraseña.
