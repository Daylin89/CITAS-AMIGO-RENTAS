package com.citasamigorenta.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class Store {
    static final Locale ES = new Locale("es");
    static final TimeZone TZ = TimeZone.getTimeZone("America/Vancouver");
    static final String DEFAULT_SELLERS =
            "[{\"name\":\"Alfredo\"},{\"name\":\"Claudia\"},{\"name\":\"Daylin\"},{\"name\":\"Edgar\"},{\"name\":\"Shirley\"}]";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("citas", Context.MODE_PRIVATE); }

    static synchronized List<JSONObject> list(Context c, String key, String def) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(key, def));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static synchronized void saveList(Context c, String key, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(key, a.toString()).apply();
    }

    static List<JSONObject> loadAppts(Context c) { return list(c, "appts", "[]"); }
    static void saveAppts(Context c, List<JSONObject> l) { saveList(c, "appts", l); Sync.soon(c, 3000); }
    static List<JSONObject> loadSellers(Context c) { return list(c, "sellers", DEFAULT_SELLERS); }
    static void saveSellers(Context c, List<JSONObject> l) { saveList(c, "sellers", l); Sync.soon(c, 3000); }

    static synchronized int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).apply();
        return n;
    }

    // ---------- Ajustes ----------
    static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    static void putS(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    static String companyWa(Context c) { return get(c, "companyWa", "+17783251552"); }

    static String sellerField(Context c, String name, String field) {
        for (JSONObject s : loadSellers(c)) if (s.optString("name").equals(name)) return s.optString(field);
        return "";
    }

    static boolean installed(Context c, String pkg) {
        try { c.getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; }
    }

    static Intent waIntent(Context c, String phone, String text) {
        String d = phone == null ? "" : phone.replaceAll("[^0-9]", "");
        if (d.length() == 10) d = "1" + d;
        String url = "https://wa.me/" + d + (text == null || text.isEmpty() ? "" : "?text=" + Uri.encode(text));
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        String pkg = get(c, "waApp", "business").equals("business") ? "com.whatsapp.w4b" : "com.whatsapp";
        if (installed(c, pkg)) i.setPackage(pkg);
        return i;
    }

    // ---------- Fechas ----------
    static SimpleDateFormat f(String p) { SimpleDateFormat s = new SimpleDateFormat(p, Locale.US); s.setTimeZone(TZ); return s; }
    static SimpleDateFormat fe(String p) { SimpleDateFormat s = new SimpleDateFormat(p, ES); s.setTimeZone(TZ); return s; }
    static Calendar cal() { return Calendar.getInstance(TZ); }
    static String today() { return f("yyyy-MM-dd").format(new Date()); }
    static String addDays(int n) {
        Calendar c = cal();
        c.add(Calendar.DAY_OF_MONTH, n);
        return f("yyyy-MM-dd").format(c.getTime());
    }
    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }
    static String niceDate(String iso) {
        try { return cap(fe("EEE d MMM yyyy").format(f("yyyy-MM-dd").parse(iso))); }
        catch (Exception e) { return iso; }
    }
    static String shortDate(String iso) {
        try { return fe("d MMM").format(f("yyyy-MM-dd").parse(iso)); }
        catch (Exception e) { return iso; }
    }
    static String niceTime(String t) {
        try { return f("h:mm a").format(f("HH:mm").parse(t)); }
        catch (Exception e) { return t; }
    }
    static long millis(String date, String time) {
        try { return f("yyyy-MM-dd HH:mm").parse(date + " " + time).getTime(); }
        catch (Exception e) { return -1; }
    }

    // ---------- Recordatorios ----------
    static void schedule(Context c, JSONObject a) {
        cancel(c, a);
        int id = a.optInt("id");
        String nm = a.optString("name");
        String addr = a.optString("address");
        String ph = a.optString("phone");
        String booked = a.optString("booked");
        String attends = a.optString("attends");
        // con el equipo conectado, cada teléfono solo recibe los avisos de las citas de su vendedor
        String me = get(c, "me", "").trim();
        if (!me.isEmpty() && !me.equalsIgnoreCase(booked) && !me.equalsIgnoreCase(attends)) return;
        if (a.optBoolean("reminder", true) && "Programada".equals(a.optString("status"))) {
            long start = millis(a.optString("date"), a.optString("time"));
            String when = niceTime(a.optString("time"));
            String where = addr.isEmpty() ? "" : " en " + addr;
            // 2 horas antes: quien agendó reconfirma con el cliente
            String msgCli = "Hola " + nm + ", le escribimos de Amigo Renta para confirmar su cita de hoy a las "
                    + when + where + ". ¿Nos confirma su asistencia? Cualquier duda, escríbanos al " + companyWa(c) + ".";
            set(c, id * 100, start - 2 * 3600000L, "Reconfirmar cita en 2 horas: " + nm,
                    when + " · " + addr + " · Agendó: " + booked,
                    ph.isEmpty() ? null : "Reconfirmar con el cliente", ph, msgCli);
            // 1 hora antes: recordar a quien atenderá
            String aPh = sellerField(c, attends, "phone");
            String msgAt = "Hola " + attends + ", recordatorio: tienes cita hoy a las " + when + " con " + nm
                    + (ph.isEmpty() ? "" : " (" + ph + ")") + where + ".";
            set(c, id * 100 + 99, start - 3600000L, "Cita en 1 hora · atiende " + attends,
                    when + " · " + nm + " · " + addr,
                    aPh.isEmpty() ? null : "Avisar a " + attends, aPh, msgAt);
        }
        JSONArray fu = a.optJSONArray("followups");
        if (fu != null) {
            for (int i = 0; i < fu.length() && i < 98; i++) {
                JSONObject x = fu.optJSONObject(i);
                if (x == null || x.optBoolean("done")) continue;
                long t = millis(x.optString("date"), x.optString("time"));
                String txt = x.optString("notes").isEmpty() ? addr : x.optString("notes");
                set(c, id * 100 + i + 1, t, "Seguimiento: " + nm, txt, null, null, null);
            }
        }
    }

    static void set(Context c, int code, long when, String title, String text, String action, String waPhone, String waText) {
        if (when <= System.currentTimeMillis()) return;
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", title);
        i.putExtra("text", text);
        i.putExtra("code", code);
        if (action != null) {
            i.putExtra("action", action);
            i.putExtra("waPhone", waPhone);
            i.putExtra("waText", waText);
        }
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static void cancel(Context c, JSONObject a) {
        int id = a.optInt("id");
        JSONArray fu = a.optJSONArray("followups");
        int n = Math.min((fu == null ? 0 : fu.length()) + 2, 99);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int k = 0; k <= 99; k++) {
            if (k >= n && k != 99) continue;
            Intent i = new Intent(c, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, id * 100 + k, i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    static void scheduleAll(Context c) {
        for (JSONObject a : loadAppts(c)) schedule(c, a);
    }
}
