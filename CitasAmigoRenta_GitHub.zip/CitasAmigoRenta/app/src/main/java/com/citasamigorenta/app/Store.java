package com.citasamigorenta.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Store {
    static final Locale ES = new Locale("es");
    static final String DEFAULT_SELLERS =
            "[{\"name\":\"Alfredo\"},{\"name\":\"Claudia\"},{\"name\":\"Daylin\"},{\"name\":\"Edgar\"},{\"name\":\"Shirley\"}]";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("citas", Context.MODE_PRIVATE); }

    static List<JSONObject> list(Context c, String key, String def) {
        ArrayList<JSONObject> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(key, def));
            for (int i = 0; i < a.length(); i++) r.add(a.getJSONObject(i));
        } catch (Exception e) { }
        return r;
    }

    static void saveList(Context c, String key, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        sp(c).edit().putString(key, a.toString()).apply();
    }

    static List<JSONObject> loadAppts(Context c) { return list(c, "appts", "[]"); }
    static void saveAppts(Context c, List<JSONObject> l) { saveList(c, "appts", l); }
    static List<JSONObject> loadSellers(Context c) { return list(c, "sellers", DEFAULT_SELLERS); }
    static void saveSellers(Context c, List<JSONObject> l) { saveList(c, "sellers", l); }

    static int nextId(Context c) {
        int n = sp(c).getInt("nextId", 1);
        sp(c).edit().putInt("nextId", n + 1).apply();
        return n;
    }

    // ---------- Fechas ----------
    static SimpleDateFormat f(String p) { return new SimpleDateFormat(p, Locale.US); }
    static String today() { return f("yyyy-MM-dd").format(new Date()); }
    static String addDays(int n) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_MONTH, n);
        return f("yyyy-MM-dd").format(c.getTime());
    }
    static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(ES) + s.substring(1); }
    static String niceDate(String iso) {
        try { return cap(new SimpleDateFormat("EEE d MMM yyyy", ES).format(f("yyyy-MM-dd").parse(iso))); }
        catch (Exception e) { return iso; }
    }
    static String shortDate(String iso) {
        try { return new SimpleDateFormat("d MMM", ES).format(f("yyyy-MM-dd").parse(iso)); }
        catch (Exception e) { return iso; }
    }
    static String niceTime(String t) {
        try { return f("h:mm a").format(f("HH:mm").parse(t)); }
        catch (Exception e) { return t; }
    }
    static long millis(String date, String time) {
        try { return f("yyyy-MM-dd HH:mm").parse(date + " " + time).getTime(); }
        catch (Exception e) { return -1; }
    }

    // ---------- Recordatorios ----------
    static void schedule(Context c, JSONObject a) {
        cancel(c, a);
        int id = a.optInt("id");
        String nm = a.optString("name");
        String addr = a.optString("address");
        if (a.optBoolean("reminder", true) && "Programada".equals(a.optString("status"))) {
            long t = millis(a.optString("date"), a.optString("time")) - 30 * 60000L;
            set(c, id * 100, t, "Cita en 30 minutos: " + nm,
                    niceTime(a.optString("time")) + " · " + addr + " · Atiende: " + a.optString("attends"));
        }
        JSONArray fu = a.optJSONArray("followups");
        if (fu != null) {
            for (int i = 0; i < fu.length() && i < 99; i++) {
                JSONObject x = fu.optJSONObject(i);
                if (x == null || x.optBoolean("done")) continue;
                long t = millis(x.optString("date"), x.optString("time"));
                String txt = x.optString("notes").isEmpty() ? addr : x.optString("notes");
                set(c, id * 100 + i + 1, t, "Seguimiento: " + nm, txt);
            }
        }
    }

    static void set(Context c, int code, long when, String title, String text) {
        if (when <= System.currentTimeMillis()) return;
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("title", title);
        i.putExtra("text", text);
        i.putExtra("code", code);
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static void cancel(Context c, JSONObject a) {
        int id = a.optInt("id");
        JSONArray fu = a.optJSONArray("followups");
        int n = (fu == null ? 0 : fu.length()) + 2;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        for (int k = 0; k < n && k < 100; k++) {
            Intent i = new Intent(c, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(c, id * 100 + k, i,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
            if (pi != null) { am.cancel(pi); pi.cancel(); }
        }
    }

    static void scheduleAll(Context c) {
        for (JSONObject a : loadAppts(c)) schedule(c, a);
    }
}
