package com.citasamigorenta.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Comparte las citas y los vendedores con el servidor de Amigo Renta (el mismo de la app Clientes).
 * Se mandan solo los campos que cambiaron; el servidor guarda el último valor de cada campo.
 */
public class Sync {
    static final String[] APPT_F = {"name", "phone", "address", "price", "date", "time", "booked", "attends", "status", "notes", "reminder", "created", "followups", "by"};
    static final String[] CFG_F = {"sellers", "companyWa"};
    static volatile long lastRun = 0;
    static volatile boolean running = false, hold = false, deferred = false;
    static volatile Runnable onChange = null;

    static boolean on(Context c) { return Net.ready(c); }

    static String norm(Object v) {
        if (v == null || v == JSONObject.NULL) return "";
        if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (d == 0) return "";
            return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d);
        }
        if (v instanceof Boolean) return ((Boolean) v) ? "true" : "";
        return v.toString();
    }

    static String devTag(Context c) {
        String t = Store.get(c, "devTag", "");
        if (t.isEmpty()) { t = Long.toString(System.nanoTime() % 2176782336L, 36); Store.putS(c, "devTag", t); }
        return t;
    }

    static JSONObject snap(Context c) {
        try { return new JSONObject(Store.get(c, "syncSnap", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    static JSONObject cfg(Context c) {
        JSONObject o = new JSONObject();
        try {
            JSONArray s = new JSONArray();
            for (JSONObject x : Store.loadSellers(c)) s.put(x);
            o.put("sellers", s);
            o.put("companyWa", Store.companyWa(c));
        } catch (Exception ignored) { }
        return o;
    }

    static void applyCfg(Context c, String k, Object v) {
        try {
            if (k.equals("sellers")) Store.saveList(c, "sellers", toList(v instanceof JSONArray ? (JSONArray) v : new JSONArray(String.valueOf(v))));
            else Store.putS(c, k, v == JSONObject.NULL ? "" : String.valueOf(v));
        } catch (Exception ignored) { }
    }

    static List<JSONObject> toList(JSONArray a) {
        List<JSONObject> l = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i) != null) l.add(a.optJSONObject(i));
        return l;
    }

    static void auto(Context c) {
        if (hold) { deferred = true; return; }
        deferred = false;
        run(c);
    }

    static String run(Context c) {
        if (!on(c)) return "Falta configurar el servidor";
        if (running) return null;
        running = true;
        try { return doRun(c); } finally { running = false; lastRun = System.currentTimeMillis(); }
    }

    static String doRun(Context c) {
        try {
            JSONObject snap = snap(c);
            List<JSONObject> appts;
            synchronized (Store.class) {
                appts = Store.loadAppts(c);
                boolean add = false;
                for (JSONObject a : appts) if (a.optString("uid").isEmpty()) { a.put("uid", "d-" + devTag(c) + "-" + a.optInt("id")); add = true; }
                if (add) Store.saveList(c, "appts", appts);
            }
            // ---------- 1. lo que cambió aquí ----------
            JSONArray recs = new JSONArray();
            Map<String, Map<String, String>> base = new HashMap<>();
            Set<String> live = new HashSet<>();
            for (JSONObject a : appts) {
                String sid = "appt:" + a.optString("uid");
                live.add(sid);
                JSONObject s = snap.optJSONObject(sid), set = new JSONObject();
                Map<String, String> b = new HashMap<>();
                for (String k : APPT_F) {
                    Object v = a.opt(k);
                    String now = norm(v), old = s == null ? null : s.optString(k, "");
                    b.put(k, now);
                    if (old == null ? !now.isEmpty() : !now.equals(old)) set.put(k, v == null ? "" : v);
                }
                base.put(sid, b);
                if (set.length() > 0) recs.put(new JSONObject().put("kind", "appt").put("id", a.optString("uid")).put("set", set));
            }
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { // citas borradas en este teléfono
                String sid = it.next();
                if (sid.startsWith("appt:") && !live.contains(sid))
                    recs.put(new JSONObject().put("kind", "appt").put("id", sid.substring(5)).put("set", new JSONObject().put("deleted", true)));
            }
            JSONObject cfg = cfg(c), cs0 = snap.optJSONObject("cfg"), cset = new JSONObject();
            Map<String, String> cb = new HashMap<>();
            for (String k : CFG_F) {
                String now = norm(cfg.opt(k)), old = cs0 == null ? null : cs0.optString(k, "");
                cb.put(k, now);
                if (old == null ? !now.isEmpty() : !now.equals(old)) cset.put(k, cfg.opt(k));
            }
            if (cs0 == null) { cset = new JSONObject(); cb = null; } // la primera vez primero se reciben los vendedores del equipo
            if (cset.length() > 0) recs.put(new JSONObject().put("kind", "ccfg").put("id", "main").put("set", cset));
            // ---------- 2. enviar ----------
            if (recs.length() > 0) {
                JSONObject body = new JSONObject().put("records", recs).put("dev", devTag(c));
                Net.Res r = Net.request(c, "POST", "/api/push", body.toString().getBytes(StandardCharsets.UTF_8), "application/json", null);
                if (r.error != null || r.code != 200) return Net.errorOf(r.code, r.body, r.error);
            }
            for (Map.Entry<String, Map<String, String>> e : base.entrySet()) snap.put(e.getKey(), new JSONObject(e.getValue()));
            for (Iterator<String> it = snap.keys(); it.hasNext(); ) { String sid = it.next(); if (sid.startsWith("appt:") && !live.contains(sid)) it.remove(); }
            if (cb != null) snap.put("cfg", new JSONObject(cb));
            // ---------- 3. traer ----------
            long lastPull = snap.has("cfg") ? Store.sp(c).getLong("lastPull", 0) : 0;
            Net.Res r = Net.request(c, "GET", "/api/changes?kinds=appt,ccfg&since=" + Math.max(0, lastPull - 120000), null, null, null);
            if (r.error != null || r.code != 200) { Store.putS(c, "syncSnap", snap.toString()); return Net.errorOf(r.code, r.body, r.error); }
            JSONObject res = new JSONObject(Net.text(r.body));
            JSONArray in = res.getJSONArray("records");
            boolean chg = false, gotCfg = false;
            synchronized (Store.class) {
                List<JSONObject> la = Store.loadAppts(c);
                List<JSONObject> touched = new ArrayList<>();
                for (int i = 0; i < in.length(); i++) {
                    JSONObject rec = in.getJSONObject(i);
                    String kind = rec.optString("kind"), rid = rec.optString("id");
                    JSONObject data = rec.optJSONObject("data");
                    if (data == null) continue;
                    if (kind.equals("ccfg")) {
                        gotCfg = true;
                        JSONObject s0 = snap.optJSONObject("cfg"), loc = cfg(c), ns = new JSONObject();
                        for (String k : CFG_F) {
                            Object sv = data.opt(k);
                            String cur = norm(loc.opt(k)), was = s0 == null ? cur : s0.optString(k, "");
                            if (cur.equals(was)) { if (sv != null && !norm(sv).equals(cur)) { applyCfg(c, k, sv); chg = true; } ns.put(k, sv == null ? "" : norm(sv)); }
                            else ns.put(k, was);
                        }
                        snap.put("cfg", ns);
                        continue;
                    }
                    if (!kind.equals("appt")) continue;
                    String sid = "appt:" + rid;
                    JSONObject a = null;
                    for (JSONObject x : la) if (x.optString("uid").equals(rid)) a = x;
                    if (data.optBoolean("deleted")) {
                        if (a != null) { Store.cancel(c, a); la.remove(a); chg = true; }
                        snap.remove(sid);
                        continue;
                    }
                    JSONObject s = snap.optJSONObject(sid);
                    if (a == null) {
                        a = new JSONObject();
                        a.put("id", Store.nextId(c));
                        a.put("uid", rid);
                        la.add(a);
                        s = null;
                    }
                    JSONObject ns = new JSONObject();
                    boolean mine = false;
                    for (String k : APPT_F) {
                        Object sv = data.opt(k);
                        String cur = norm(a.opt(k)), was = s == null ? cur : s.optString(k, "");
                        if (cur.equals(was)) {
                            if (sv != null && !norm(sv).equals(cur)) { a.put(k, sv); chg = true; mine = true; }
                            ns.put(k, sv == null ? "" : norm(sv));
                        } else ns.put(k, was);
                    }
                    snap.put(sid, ns);
                    if (mine) touched.add(a);
                }
                if (chg) Store.saveList(c, "appts", la);
                for (JSONObject a : touched) Store.schedule(c, a);
                if (!snap.has("cfg") && !gotCfg) { snap.put("cfg", new JSONObject()); soon(c, 2000); } // el servidor aún no tiene vendedores
                Store.putS(c, "syncSnap", snap.toString());
                Store.sp(c).edit().putLong("lastPull", res.optLong("now")).putLong("lastSyncOk", System.currentTimeMillis()).apply();
            }
            if (chg) { Runnable r2 = onChange; if (r2 != null) H.post(() -> { Runnable r3 = onChange; if (r3 != null) r3.run(); }); }
            return null;
        } catch (Exception e) {
            return "Error al sincronizar: " + e.getMessage();
        }
    }

    // ---------- cuándo sincronizar ----------
    static final Handler H = new Handler(Looper.getMainLooper());
    static final Runnable[] PENDING = {null};

    static void soon(Context c, long delayMs) {
        if (!on(c)) return;
        final Context app = c.getApplicationContext();
        if (PENDING[0] != null) H.removeCallbacks(PENDING[0]);
        PENDING[0] = () -> new Thread(() -> auto(app)).start();
        H.postDelayed(PENDING[0], delayMs);
    }

    static void schedule(Context c) {
        PendingIntent pi = PendingIntent.getBroadcast(c, 31, new Intent(c, Rx.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_FIFTEEN_MINUTES, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
    }

    public static class Rx extends BroadcastReceiver {
        @Override
        public void onReceive(Context c, Intent i) {
            if (!on(c)) return;
            final PendingResult pr = goAsync();
            new Thread(() -> { try { auto(c); } finally { pr.finish(); } }).start();
        }
    }
}
