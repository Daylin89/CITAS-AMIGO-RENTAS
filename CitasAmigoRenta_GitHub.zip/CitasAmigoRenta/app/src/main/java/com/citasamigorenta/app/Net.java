package com.citasamigorenta.app;

import android.app.Activity;
import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Llamadas al servidor de Amigo Renta (Cloudflare). */
public class Net {
    interface Cb { void on(int code, byte[] body, String error); }

    static class Res { int code; byte[] body; String error; }

    static String base(Context a) {
        String u = Store.get(a, "srvUrl", "").trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        if (!u.isEmpty() && !u.startsWith("http")) u = "https://" + u;
        return u;
    }

    static boolean ready(Context a) { return !base(a).isEmpty() && !Store.get(a, "srvKey", "").isEmpty(); }

    /** Llamada directa (usar fuera de la pantalla principal, en segundo plano). */
    static Res request(Context a, String method, String path, byte[] body, String contentType, Map<String, String> headers) {
        Res r = new Res();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(base(a) + path).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(20000);
            c.setReadTimeout(60000);
            c.setRequestProperty("X-Device-Key", Store.get(a, "srvKey", ""));
            if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", contentType == null ? "application/octet-stream" : contentType);
                c.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = c.getOutputStream()) { os.write(body); }
            }
            r.code = c.getResponseCode();
            InputStream is = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            r.body = is == null ? new byte[0] : readAll(is);
        } catch (Exception e) {
            r.error = "Sin conexión con el servidor (" + e.getClass().getSimpleName() + ")";
        } finally { if (c != null) c.disconnect(); }
        return r;
    }

    /** Llamada en segundo plano que responde en la pantalla. */
    static void call(Activity a, String method, String path, byte[] body, String contentType, Map<String, String> headers, Cb cb) {
        new Thread(() -> {
            Res r = request(a, method, path, body, contentType, headers);
            a.runOnUiThread(() -> cb.on(r.code, r.body, r.error));
        }).start();
    }

    static byte[] readAll(InputStream is) throws java.io.IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = is.read(buf)) > 0) b.write(buf, 0, n);
        is.close();
        return b.toByteArray();
    }

    static String text(byte[] b) { return b == null ? "" : new String(b, StandardCharsets.UTF_8); }

    static String errorOf(int code, byte[] body, String error) {
        if (error != null) return error;
        try {
            org.json.JSONObject o = new org.json.JSONObject(text(body));
            if (!o.optString("error").isEmpty()) return o.optString("error");
        } catch (Exception e) { }
        if (code == 401) return "Clave del dispositivo incorrecta (revísala en Ajustes)";
        if (code == 404) return "No encontrado en el servidor (revisa la dirección en Ajustes)";
        return "El servidor respondió " + code;
    }
}
