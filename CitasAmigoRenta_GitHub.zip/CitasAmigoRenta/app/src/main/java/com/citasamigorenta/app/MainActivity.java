package com.citasamigorenta.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    static final int PRI = 0xFF0D3B7A, PRI2 = 0xFF1565C0, BG = 0xFFF3F6FB, TXT = 0xFF1A2433,
            MUT = 0xFF6B7585, BRD = 0xFFE1E7EF, RED = 0xFFDC2626, GRN = 0xFF16A34A;
    static final int[] PAL = {0xFF16A34A, 0xFFEA580C, 0xFF2563EB, 0xFFDC2626, 0xFF0D9488, 0xFF7C3AED, 0xFFDB2777};
    static final String[] STATES = {"Programada", "Atendida", "Rentada", "Cancelada", "No asistió"};
    static final int REQ_EXPORT = 41;
    static final int TXT_CAP = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS;
    static final int TXT_MULTI = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES;

    interface Cb { void on(String s); }

    List<JSONObject> appts;
    List<JSONObject> sellers;
    FrameLayout content;
    LinearLayout header, nav;
    TextView fab;
    final ArrayList<Runnable> stack = new ArrayList<>();
    int tabSel = 0;
    String filterStatus = "Todas", search = "";
    String calDate, repFrom, repTo, expFrom, expTo, pendingCsv;

    // =====================================================================
    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        appts = Store.loadAppts(this);
        sellers = Store.loadSellers(this);
        calDate = Store.today();
        Calendar c = Calendar.getInstance();
        c.set(Calendar.DAY_OF_MONTH, 1);
        repFrom = Store.f("yyyy-MM-dd").format(c.getTime());
        c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));
        repTo = Store.f("yyyy-MM-dd").format(c.getTime());
        expFrom = repFrom;
        expTo = repTo;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        LinearLayout col = vbox();
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        header = hbox();
        header.setBackgroundColor(PRI);
        header.setPadding(dp(16), dp(14), dp(16), dp(14));
        col.addView(header, new LinearLayout.LayoutParams(-1, -2));

        content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        nav = buildNav();
        col.addView(nav, new LinearLayout.LayoutParams(-1, -2));

        fab = tv("＋  Nueva cita", 15, Color.WHITE, true);
        fab.setBackground(round(PRI2, 28));
        fab.setPadding(dp(22), dp(14), dp(22), dp(14));
        fab.setElevation(dp(6));
        fab.setOnClickListener(v -> open(() -> form(-1)));
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        fl.setMargins(0, 0, dp(16), dp(84));
        root.addView(fab, fl);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7);

        openTab(0);
    }

    // ============================ Navegación ============================
    void open(Runnable r) { stack.add(r); r.run(); }

    void openTab(int k) {
        tabSel = k;
        stack.clear();
        if (k == 0) open(this::home);
        else if (k == 1) open(this::citas);
        else if (k == 2) open(this::calendar);
        else if (k == 3) open(this::reports);
        else open(this::more);
    }

    void goBack() {
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1);
            stack.get(stack.size() - 1).run();
        } else if (tabSel != 0) {
            openTab(0);
        } else {
            finish();
        }
    }

    @Override
    public void onBackPressed() { goBack(); }

    void setHeader(String title, String sub, String icon, boolean back) {
        header.removeAllViews();
        if (back) {
            TextView bk = tv("←", 24, Color.WHITE, true);
            bk.setPadding(dp(2), 0, dp(16), 0);
            bk.setOnClickListener(v -> goBack());
            header.addView(bk);
        } else if (icon != null) {
            TextView ic = tv(icon, 24, Color.WHITE, false);
            ic.setPadding(0, 0, dp(12), 0);
            header.addView(ic);
        }
        LinearLayout t = vbox();
        t.addView(tv(title, 20, Color.WHITE, true));
        if (sub != null) t.addView(tv(sub, 13, 0xFFCFE0FF, false));
        header.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
    }

    void show(View body, boolean navOn, boolean fabOn) {
        content.removeAllViews();
        content.addView(body, new FrameLayout.LayoutParams(-1, -1));
        nav.setVisibility(navOn ? View.VISIBLE : View.GONE);
        fab.setVisibility(fabOn ? View.VISIBLE : View.GONE);
        refreshNav();
    }

    static final String[][] TABS = {{"🏠", "Inicio"}, {"📋", "Citas"}, {"📅", "Calendario"}, {"📊", "Reportes"}, {"☰", "Más"}};

    LinearLayout buildNav() {
        LinearLayout n = hbox();
        n.setBackgroundColor(Color.WHITE);
        n.setElevation(dp(10));
        n.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < TABS.length; i++) {
            final int k = i;
            LinearLayout it = vbox();
            it.setGravity(Gravity.CENTER);
            it.setPadding(0, dp(6), 0, dp(6));
            TextView ic = tv(TABS[i][0], 19, TXT, false);
            ic.setGravity(Gravity.CENTER);
            TextView lb = tv(TABS[i][1], 11, MUT, false);
            lb.setGravity(Gravity.CENTER);
            it.addView(ic);
            it.addView(lb);
            it.setTag(lb);
            it.setOnClickListener(v -> openTab(k));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            n.addView(it, lp);
        }
        return n;
    }

    void refreshNav() {
        for (int i = 0; i < nav.getChildCount(); i++) {
            View it = nav.getChildAt(i);
            TextView lb = (TextView) it.getTag();
            boolean s = i == tabSel;
            lb.setTextColor(s ? PRI2 : MUT);
            lb.setTypeface(s ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            it.setBackground(s ? round(0xFFEAF1FF, 12) : null);
        }
    }

    // ============================ Inicio ============================
    void home() {
        setHeader("Mis Citas", "Gestión de propiedades", "🏠", false);
        LinearLayout p = vbox();
        String month = Store.today().substring(0, 7);
        int tot = 0, at = 0, re = 0, ca = 0;
        for (JSONObject a : appts) {
            if (!a.optString("date").startsWith(month)) continue;
            tot++;
            String s = a.optString("status");
            if (s.equals("Atendida")) at++;
            else if (s.equals("Rentada")) re++;
            else if (s.equals("Cancelada")) ca++;
        }
        String mName = new SimpleDateFormat("MMMM", Store.ES).format(new Date());
        p.addView(sectionTitle("Resumen de " + mName, null, null));
        p.addView(statsRow(tot, at, re, ca));

        String today = Store.today();
        p.addView(sectionTitle("Citas de hoy", "Ver todas ›", v -> openTab(1)));
        List<JSONObject> list = new ArrayList<>();
        for (JSONObject a : appts) if (a.optString("date").equals(today)) list.add(a);
        sortAsc(list);
        if (list.isEmpty()) p.addView(empty("No hay citas para hoy"));
        for (JSONObject a : list) p.addView(apptRow(a, false));

        LinearLayout fus = vbox();
        for (JSONObject a : appts) {
            JSONArray fu = a.optJSONArray("followups");
            if (fu == null) continue;
            for (int i = 0; i < fu.length(); i++) {
                JSONObject f = fu.optJSONObject(i);
                if (f != null && !f.optBoolean("done") && f.optString("date").compareTo(today) <= 0)
                    fus.addView(fuRow(a, f, true));
            }
        }
        if (fus.getChildCount() > 0) {
            p.addView(sectionTitle("Seguimientos pendientes", null, null));
            p.addView(fus);
        }

        List<JSONObject> next = new ArrayList<>();
        for (JSONObject a : appts)
            if (a.optString("date").compareTo(today) > 0 && a.optString("status").equals("Programada")) next.add(a);
        sortAsc(next);
        if (!next.isEmpty()) {
            p.addView(sectionTitle("Próximas citas", null, null));
            for (int i = 0; i < next.size() && i < 5; i++) p.addView(apptRow(next.get(i), true));
        }
        show(scroll(p), true, true);
    }

    View statsRow(int tot, int at, int re, int ca) {
        LinearLayout row = hbox();
        row.setPadding(dp(10), 0, dp(10), 0);
        row.addView(stat("📋", tot, "Citas", PRI2, 0xFFEAF1FF));
        row.addView(stat("✅", at, "Atendidas", 0xFF15803D, 0xFFE3F6E8));
        row.addView(stat("🏠", re, "Rentadas", 0xFF1D4ED8, 0xFFE4ECFF));
        row.addView(stat("❌", ca, "Canceladas", 0xFFB91C1C, 0xFFFDE6E6));
        return row;
    }

    View stat(String ic, int n, String label, int fg, int bg) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(0, dp(12), 0, dp(12));
        TextView i = tv(ic, 18, fg, false);
        TextView num = tv(String.valueOf(n), 22, fg, true);
        TextView l = tv(label, 11, fg, false);
        i.setGravity(Gravity.CENTER);
        num.setGravity(Gravity.CENTER);
        l.setGravity(Gravity.CENTER);
        l.setMaxLines(1);
        b.addView(i);
        b.addView(num);
        b.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    // ============================ Lista de citas ============================
    void citas() {
        setHeader("Todas las citas", appts.size() + " registradas", null, false);
        LinearLayout p = vbox();
        EditText s = input("🔍  Buscar por nombre, teléfono o dirección", InputType.TYPE_CLASS_TEXT);
        s.setText(search);
        ((LinearLayout.LayoutParams) s.getLayoutParams()).setMargins(dp(14), dp(10), dp(14), dp(4));
        p.addView(s);

        LinearLayout chips = hbox();
        chips.setPadding(dp(10), dp(6), dp(10), dp(6));
        String[] opts = {"Todas", "Programada", "Atendida", "Rentada", "Cancelada", "No asistió"};
        for (String o : opts) {
            chips.addView(chip(o, o.equals(filterStatus), v -> { filterStatus = o; citas(); }));
        }
        p.addView(hscroll(chips));

        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            list.removeAllViews();
            String q = search.toLowerCase(Store.ES);
            String today = Store.today();
            List<JSONObject> up = new ArrayList<>(), past = new ArrayList<>();
            for (JSONObject a : appts) {
                if (!filterStatus.equals("Todas") && !a.optString("status").equals(filterStatus)) continue;
                String hay = (a.optString("name") + " " + a.optString("phone") + " " + a.optString("address")).toLowerCase(Store.ES);
                if (!q.isEmpty() && !hay.contains(q)) continue;
                if (a.optString("date").compareTo(today) >= 0) up.add(a); else past.add(a);
            }
            sortAsc(up);
            sortAsc(past);
            Collections.reverse(past);
            if (up.isEmpty() && past.isEmpty()) list.addView(empty("No se encontraron citas"));
            if (!up.isEmpty()) {
                list.addView(sectionTitle("Próximas (" + up.size() + ")", null, null));
                for (JSONObject a : up) list.addView(apptRow(a, true));
            }
            if (!past.isEmpty()) {
                list.addView(sectionTitle("Anteriores (" + past.size() + ")", null, null));
                for (JSONObject a : past) list.addView(apptRow(a, true));
            }
        };
        s.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void onTextChanged(CharSequence x, int a1, int a2, int a3) { }
            public void afterTextChanged(Editable e) { search = e.toString(); fill.run(); }
        });
        fill.run();
        show(scroll(p), true, true);
    }

    View apptRow(JSONObject a, boolean showDate) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = vbox();
        if (showDate) left.addView(tv(Store.shortDate(a.optString("date")), 13, PRI2, true));
        left.addView(tv(Store.niceTime(a.optString("time")), 13, TXT, true));
        c.addView(left, new LinearLayout.LayoutParams(dp(74), -2));

        LinearLayout r = vbox();
        LinearLayout top = hbox();
        TextView nm = tv(a.optString("name"), 16, TXT, true);
        nm.setMaxLines(1);
        nm.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(nm, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(pill(a.optString("status")));
        r.addView(top);
        if (!a.optString("phone").isEmpty()) r.addView(tv("📞  " + a.optString("phone"), 13, MUT, false));
        if (!a.optString("address").isEmpty()) {
            TextView ad = tv("📍  " + a.optString("address"), 13, MUT, false);
            ad.setMaxLines(2);
            r.addView(ad);
        }
        LinearLayout bot = hbox();
        bot.setPadding(0, dp(4), 0, 0);
        TextView pr = tv(price(a), 15, TXT, true);
        bot.addView(pr, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!a.optString("attends").isEmpty()) bot.addView(tv("👤 " + a.optString("attends"), 12, MUT, false));
        r.addView(bot);
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        final int id = a.optInt("id");
        c.setOnClickListener(v -> open(() -> detail(id)));
        return c;
    }

    View fuRow(JSONObject a, JSONObject f, boolean showDate) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        TextView ic = tv("🔔", 20, TXT, false);
        ic.setPadding(0, 0, dp(12), 0);
        c.addView(ic);
        LinearLayout r = vbox();
        r.addView(tv("Seguimiento · " + a.optString("name"), 15, TXT, true));
        String when = (showDate ? Store.shortDate(f.optString("date")) + " · " : "") + Store.niceTime(f.optString("time"));
        r.addView(tv(when, 13, 0xFFB45309, true));
        if (!f.optString("notes").isEmpty()) r.addView(tv(f.optString("notes"), 13, MUT, false));
        c.addView(r, new LinearLayout.LayoutParams(0, -2, 1f));
        final int id = a.optInt("id");
        c.setOnClickListener(v -> open(() -> detail(id)));
        return c;
    }

    // ============================ Formulario ============================
    void form(int id) {
        final JSONObject old = id < 0 ? null : find(id);
        setHeader(old == null ? "Nueva cita" : "Editar cita", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        p.addView(c);

        EditText name = input("Ej. Juan Pérez", TXT_CAP);
        EditText phone = input("Ej. (604) 555-1111", InputType.TYPE_CLASS_PHONE);
        EditText addr = input("Ej. 801 E Broadway, Vancouver", TXT_CAP | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        EditText price = input("Ej. 1200", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText notes = input("Ej. Cliente interesado, quiere ver otras opciones", TXT_MULTI);
        notes.setMinLines(3);

        final String[] dSel = {old != null ? old.optString("date") : Store.today()};
        final String[] tSel = {old != null ? old.optString("time") : "10:00"};
        final TextView dateF = field("📅  " + Store.niceDate(dSel[0]));
        final TextView timeF = field("🕐  " + Store.niceTime(tSel[0]));
        dateF.setOnClickListener(v -> pickDate(dSel[0], iso -> { dSel[0] = iso; dateF.setText("📅  " + Store.niceDate(iso)); }));
        timeF.setOnClickListener(v -> pickTime(tSel[0], hm -> { tSel[0] = hm; timeF.setText("🕐  " + Store.niceTime(hm)); }));

        String[] names = sellerNames();
        TextView ag = picker(names, old != null ? old.optString("booked") : "");
        TextView at = picker(names, old != null ? old.optString("attends") : "");
        TextView st = picker(STATES, old != null ? old.optString("status") : "Programada");

        Switch rem = new Switch(this);
        rem.setText("🔔  Recordarme 30 min antes");
        rem.setTextSize(15);
        rem.setTextColor(TXT);
        rem.setChecked(old == null || old.optBoolean("reminder", true));
        rem.setPadding(0, dp(16), 0, dp(4));

        if (old != null) {
            name.setText(old.optString("name"));
            phone.setText(old.optString("phone"));
            addr.setText(old.optString("address"));
            price.setText(old.optString("price"));
            notes.setText(old.optString("notes"));
        }

        c.addView(label("👤", "Nombre del cliente", true));
        c.addView(name);
        c.addView(label("📞", "Teléfono", false));
        c.addView(phone);
        c.addView(label("📍", "Dirección de la propiedad", false));
        c.addView(addr);
        c.addView(label("💲", "Precio mensual", false));
        c.addView(price);
        c.addView(twoCols(labeled("Fecha", dateF), labeled("Hora", timeF)));
        c.addView(twoCols(labeled("Agendó", ag), labeled("Atenderá", at)));
        c.addView(label("🏷️", "Estado", false));
        c.addView(st);
        c.addView(label("📝", "Notas (opcional)", false));
        c.addView(notes);
        c.addView(rem);

        p.addView(button("Guardar cita", PRI2, v -> {
            String nm = name.getText().toString().trim();
            if (nm.isEmpty()) { toast("Escribe el nombre del cliente"); return; }
            JSONObject o = old != null ? old : new JSONObject();
            if (old == null) {
                put(o, "id", Store.nextId(this));
                put(o, "followups", new JSONArray());
                put(o, "created", System.currentTimeMillis());
            }
            put(o, "name", nm);
            put(o, "phone", phone.getText().toString().trim());
            put(o, "address", addr.getText().toString().trim());
            put(o, "price", price.getText().toString().trim());
            put(o, "date", dSel[0]);
            put(o, "time", tSel[0]);
            put(o, "booked", (String) ag.getTag());
            put(o, "attends", (String) at.getTag());
            put(o, "status", (String) st.getTag());
            put(o, "notes", notes.getText().toString().trim());
            put(o, "reminder", rem.isChecked());
            if (old == null) appts.add(o);
            Store.saveAppts(this, appts);
            Store.schedule(this, o);
            toast("Cita guardada ✅");
            goBack();
        }));
        show(scroll(p), false, false);
    }

    // ============================ Detalle ============================
    void detail(int id) {
        final JSONObject a = find(id);
        if (a == null) { goBack(); return; }
        setHeader("Detalle de la cita", null, null, true);
        LinearLayout p = vbox();

        LinearLayout c = card();
        LinearLayout top = hbox();
        top.addView(avatar(a.optString("name"), PRI2, 48));
        LinearLayout nv = vbox();
        nv.setPadding(dp(12), 0, dp(8), 0);
        nv.addView(tv(a.optString("name"), 18, TXT, true));
        if (!a.optString("phone").isEmpty()) nv.addView(tv(a.optString("phone"), 14, MUT, false));
        top.addView(nv, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(pill(a.optString("status")));
        c.addView(top);
        c.addView(divider());
        LinearLayout ar = hbox();
        TextView ad = tv("🏠  " + (a.optString("address").isEmpty() ? "Sin dirección" : a.optString("address")), 15, TXT, false);
        ar.addView(ad, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!a.optString("price").isEmpty()) {
            TextView pr = tv(price(a), 15, 0xFF15803D, true);
            pr.setBackground(round(0xFFE3F6E8, 20));
            pr.setPadding(dp(10), dp(4), dp(10), dp(4));
            ar.addView(pr);
        }
        c.addView(ar);
        c.addView(gap(10));
        c.addView(twoCols(tv("📅  " + Store.niceDate(a.optString("date")), 14, TXT, false),
                tv("🕐  " + Store.niceTime(a.optString("time")), 14, TXT, false)));
        c.addView(gap(10));
        c.addView(twoCols(personBox("Agendó", a.optString("booked")), personBox("Atenderá", a.optString("attends"))));
        p.addView(c);

        p.addView(sectionTitle("Acciones", null, null));
        LinearLayout acts = hbox();
        acts.setPadding(dp(10), 0, dp(10), 0);
        final String phone = a.optString("phone");
        final String addr = a.optString("address");
        acts.addView(action("📝", "Seguimiento", 0xFF15803D, 0xFFE3F6E8, v -> open(() -> followup(id))));
        acts.addView(action("📅", "Calendario", PRI2, 0xFFEAF1FF, v -> addToCalendar(a)));
        acts.addView(action("📍", "Mapa", 0xFF0F766E, 0xFFDDF4F1, v -> view("geo:0,0?q=" + Uri.encode(addr))));
        acts.addView(action("📞", "Llamar", 0xFF7C3AED, 0xFFF0E9FF, v -> dial(phone)));
        acts.addView(action("💬", "WhatsApp", GRN, 0xFFE3F6E8, v -> whatsapp(phone)));
        p.addView(acts);

        p.addView(sectionTitle("Cambiar estado", null, null));
        LinearLayout chips = hbox();
        chips.setPadding(dp(10), 0, dp(10), 0);
        for (String s : STATES) {
            chips.addView(chip(s, s.equals(a.optString("status")), v -> {
                put(a, "status", s);
                Store.saveAppts(this, appts);
                Store.schedule(this, a);
                detail(id);
            }));
        }
        p.addView(hscroll(chips));

        if (!a.optString("notes").isEmpty()) {
            p.addView(sectionTitle("Notas", null, null));
            LinearLayout nc = card();
            nc.addView(tv(a.optString("notes"), 15, TXT, false));
            p.addView(nc);
        }

        p.addView(sectionTitle("Historial de seguimientos", "＋ Agregar", v -> open(() -> followup(id))));
        JSONArray fu = a.optJSONArray("followups");
        if (fu == null || fu.length() == 0) p.addView(empty("Todavía no hay seguimientos"));
        else {
            LinearLayout fc = card();
            for (int i = 0; i < fu.length(); i++) {
                final JSONObject f = fu.optJSONObject(i);
                if (f == null) continue;
                if (fc.getChildCount() > 0) fc.addView(divider());
                LinearLayout row = hbox();
                CheckBox cb = new CheckBox(this);
                cb.setChecked(f.optBoolean("done"));
                cb.setOnCheckedChangeListener((btn, checked) -> {
                    put(f, "done", checked);
                    Store.saveAppts(this, appts);
                    Store.schedule(this, a);
                });
                row.addView(cb);
                LinearLayout tx = vbox();
                tx.addView(tv(Store.niceDate(f.optString("date")) + " · " + Store.niceTime(f.optString("time")), 14, TXT, true));
                if (!f.optString("notes").isEmpty()) tx.addView(tv(f.optString("notes"), 13, MUT, false));
                row.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
                fc.addView(row);
            }
            p.addView(fc);
        }

        LinearLayout btns = hbox();
        btns.setPadding(dp(8), dp(10), dp(8), 0);
        btns.addView(outline("✏️  Editar", PRI2, v -> open(() -> form(id))), new LinearLayout.LayoutParams(0, -2, 1f));
        btns.addView(outline("🗑️  Eliminar", RED, v -> new AlertDialog.Builder(this)
                .setTitle("Eliminar cita")
                .setMessage("¿Seguro que quieres eliminar la cita de " + a.optString("name") + "?")
                .setPositiveButton("Eliminar", (dlg, w) -> {
                    Store.cancel(this, a);
                    appts.remove(a);
                    Store.saveAppts(this, appts);
                    toast("Cita eliminada");
                    goBack();
                })
                .setNegativeButton("Cancelar", null)
                .show()), new LinearLayout.LayoutParams(0, -2, 1f));
        p.addView(btns);
        show(scroll(p), false, false);
    }

    View personBox(String role, String name) {
        LinearLayout b = hbox();
        b.addView(avatar(name, colorFor(name), 34));
        LinearLayout t = vbox();
        t.setPadding(dp(8), 0, 0, 0);
        t.addView(tv(role, 12, MUT, false));
        t.addView(tv(name.isEmpty() ? "—" : name, 14, TXT, true));
        b.addView(t);
        return b;
    }

    void addToCalendar(JSONObject a) {
        long start = Store.millis(a.optString("date"), a.optString("time"));
        Intent i = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + 60 * 60000L)
                .putExtra(CalendarContract.Events.TITLE, "Cita: " + a.optString("name"))
                .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("address"))
                .putExtra(CalendarContract.Events.DESCRIPTION, "Tel: " + a.optString("phone") + "\nAtiende: "
                        + a.optString("attends") + "\nAgendó: " + a.optString("booked") + "\n" + a.optString("notes"));
        launch(i);
    }

    void view(String uri) { launch(new Intent(Intent.ACTION_VIEW, Uri.parse(uri))); }

    void dial(String phone) {
        if (phone.isEmpty()) { toast("Esta cita no tiene teléfono"); return; }
        launch(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
    }

    void whatsapp(String phone) {
        String d = phone.replaceAll("[^0-9]", "");
        if (d.isEmpty()) { toast("Esta cita no tiene teléfono"); return; }
        if (d.length() == 10) d = "1" + d;
        view("https://wa.me/" + d);
    }

    void launch(Intent i) {
        try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir esto"); }
    }

    // ============================ Seguimiento ============================
    void followup(int id) {
        final JSONObject a = find(id);
        if (a == null) { goBack(); return; }
        setHeader("Seguimiento", a.optString("name"), null, true);
        LinearLayout p = vbox();

        LinearLayout c = card();
        LinearLayout top = hbox();
        top.addView(avatar(a.optString("name"), PRI2, 44));
        LinearLayout nv = vbox();
        nv.setPadding(dp(12), 0, 0, 0);
        nv.addView(tv(a.optString("name"), 17, TXT, true));
        if (!a.optString("phone").isEmpty()) nv.addView(tv(a.optString("phone"), 14, MUT, false));
        top.addView(nv, new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(top);
        if (!a.optString("address").isEmpty()) { c.addView(gap(8)); c.addView(tv("🏠  " + a.optString("address"), 14, TXT, false)); }
        c.addView(divider());
        LinearLayout lr = hbox();
        lr.addView(tv("Última cita: " + Store.shortDate(a.optString("date")) + " · " + Store.niceTime(a.optString("time")), 14, TXT, false),
                new LinearLayout.LayoutParams(0, -2, 1f));
        lr.addView(pill(a.optString("status")));
        c.addView(lr);
        if (!a.optString("attends").isEmpty()) c.addView(tv("👤  Atendió: " + a.optString("attends"), 14, MUT, false));
        p.addView(c);

        LinearLayout f = card();
        f.addView(tv("Agregar seguimiento", 17, TXT, true));
        final String[] dSel = {Store.addDays(1)};
        final String[] tSel = {"10:00"};
        final TextView dateTxt = tv("", 14, PRI2, true);
        final TextView[] ch = new TextView[3];
        final Runnable[] paint = new Runnable[1];
        String[] lbls = {"Hoy", "Mañana", "Otra fecha"};
        LinearLayout row = hbox();
        for (int i = 0; i < 3; i++) {
            final int k = i;
            ch[i] = chip(lbls[i], false, v -> {
                if (k == 0) { dSel[0] = Store.today(); paint[0].run(); }
                else if (k == 1) { dSel[0] = Store.addDays(1); paint[0].run(); }
                else pickDate(dSel[0], iso -> { dSel[0] = iso; paint[0].run(); });
            });
            row.addView(ch[i]);
        }
        paint[0] = () -> {
            int sel = dSel[0].equals(Store.today()) ? 0 : dSel[0].equals(Store.addDays(1)) ? 1 : 2;
            for (int i = 0; i < 3; i++) styleChip(ch[i], i == sel);
            dateTxt.setText("📅  " + Store.niceDate(dSel[0]));
        };
        paint[0].run();
        f.addView(label("📅", "Fecha", true));
        f.addView(row);
        f.addView(dateTxt);
        final TextView timeF = field("🕐  " + Store.niceTime(tSel[0]));
        timeF.setOnClickListener(v -> pickTime(tSel[0], hm -> { tSel[0] = hm; timeF.setText("🕐  " + Store.niceTime(hm)); }));
        f.addView(label("🕐", "Hora", true));
        f.addView(timeF);
        EditText notes = input("Ej. Llamar para confirmar si sigue interesado", TXT_MULTI);
        notes.setMinLines(3);
        f.addView(label("📝", "Notas (opcional)", false));
        f.addView(notes);
        p.addView(f);

        p.addView(button("Guardar seguimiento", PRI2, v -> {
            JSONObject x = new JSONObject();
            put(x, "date", dSel[0]);
            put(x, "time", tSel[0]);
            put(x, "notes", notes.getText().toString().trim());
            put(x, "done", false);
            JSONArray fu = a.optJSONArray("followups");
            if (fu == null) { fu = new JSONArray(); put(a, "followups", fu); }
            fu.put(x);
            Store.saveAppts(this, appts);
            Store.schedule(this, a);
            toast("Seguimiento guardado 🔔");
            goBack();
        }));
        show(scroll(p), false, false);
    }

    // ============================ Calendario ============================
    void calendar() {
        setHeader("Calendario", null, "📅", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.setPadding(dp(4), dp(4), dp(4), dp(4));
        CalendarView cv = new CalendarView(this);
        long ms = Store.millis(calDate, "12:00");
        if (ms > 0) cv.setDate(ms, false, true);
        c.addView(cv, new LinearLayout.LayoutParams(-1, dp(330)));
        p.addView(c);

        final TextView title = tv("", 17, TXT, true);
        title.setPadding(dp(18), dp(14), dp(18), dp(6));
        p.addView(title);
        final LinearLayout list = vbox();
        p.addView(list);
        final Runnable fill = () -> {
            title.setText(Store.niceDate(calDate));
            list.removeAllViews();
            List<JSONObject> day = new ArrayList<>();
            for (JSONObject a : appts) if (a.optString("date").equals(calDate)) day.add(a);
            sortAsc(day);
            for (JSONObject a : day) list.addView(apptRow(a, false));
            for (JSONObject a : appts) {
                JSONArray fu = a.optJSONArray("followups");
                if (fu == null) continue;
                for (int i = 0; i < fu.length(); i++) {
                    JSONObject f = fu.optJSONObject(i);
                    if (f != null && f.optString("date").equals(calDate)) list.addView(fuRow(a, f, false));
                }
            }
            if (list.getChildCount() == 0) list.addView(empty("No hay citas este día"));
        };
        cv.setOnDateChangeListener((cvw, yy, mm, dd) -> {
            calDate = String.format(Locale.US, "%04d-%02d-%02d", yy, mm + 1, dd);
            fill.run();
        });
        fill.run();
        show(scroll(p), true, true);
    }

    // ============================ Reportes ============================
    void reports() {
        setHeader("Reportes", null, "📊", false);
        LinearLayout p = vbox();
        p.addView(rangeCard(repFrom, repTo, iso -> { repFrom = iso; reports(); }, iso -> { repTo = iso; reports(); }));

        List<JSONObject> in = inRange(repFrom, repTo);
        int[] cnt = new int[STATES.length];
        for (JSONObject a : in) {
            for (int i = 0; i < STATES.length; i++) if (STATES[i].equals(a.optString("status"))) cnt[i]++;
        }
        p.addView(statsRow(in.size(), cnt[1], cnt[2], cnt[3]));
        if (in.size() > 0) {
            int pct = Math.round(cnt[2] * 100f / in.size());
            TextView conv = tv("🏆  Tasa de renta: " + pct + "% de las citas terminaron en renta", 14, 0xFF15803D, true);
            conv.setPadding(dp(18), dp(8), dp(18), 0);
            p.addView(conv);
        }

        p.addView(sectionTitle("Rendimiento por vendedor", null, null));
        LinearLayout t = card();
        t.addView(tableRow(new String[]{"Vendedor", "Agendó", "Atiende", "Rent.", "Canc."}, true, null));
        for (int k = 0; k < sellers.size(); k++) {
            String n = sellers.get(k).optString("name");
            int ag = 0, att = 0, re = 0, ca = 0;
            for (JSONObject a : in) {
                if (a.optString("booked").equals(n)) ag++;
                if (a.optString("attends").equals(n)) {
                    att++;
                    if (a.optString("status").equals("Rentada")) re++;
                    if (a.optString("status").equals("Cancelada")) ca++;
                }
            }
            t.addView(divider());
            t.addView(tableRow(new String[]{n, "" + ag, "" + att, "" + re, "" + ca}, false, PAL[k % PAL.length]));
        }
        p.addView(t);

        p.addView(sectionTitle("Estado de citas", null, null));
        LinearLayout dc = card();
        dc.setOrientation(LinearLayout.HORIZONTAL);
        dc.setGravity(Gravity.CENTER_VERTICAL);
        float[] vals = new float[STATES.length];
        int[] cols = new int[STATES.length];
        LinearLayout leg = vbox();
        leg.setPadding(dp(18), 0, 0, 0);
        for (int i = 0; i < STATES.length; i++) {
            vals[i] = cnt[i];
            cols[i] = stColors(STATES[i])[0];
            LinearLayout lr = hbox();
            lr.setPadding(0, dp(3), 0, dp(3));
            lr.addView(tv("● ", 14, cols[i], true));
            lr.addView(tv(STATES[i], 13, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
            int pc = in.isEmpty() ? 0 : Math.round(cnt[i] * 100f / in.size());
            lr.addView(tv(pc + "%", 13, TXT, true));
            leg.addView(lr);
        }
        dc.addView(new Donut(this, vals, cols), new LinearLayout.LayoutParams(dp(120), dp(120)));
        dc.addView(leg, new LinearLayout.LayoutParams(0, -2, 1f));
        p.addView(dc);

        p.addView(button("📤  Exportar a Excel", GRN, v -> { expFrom = repFrom; expTo = repTo; open(this::export); }));
        show(scroll(p), true, false);
    }

    View tableRow(String[] cells, boolean head, Integer color) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        for (int i = 0; i < cells.length; i++) {
            if (i == 0 && color != null) {
                LinearLayout nb = hbox();
                nb.addView(avatar(cells[0], color, 28));
                TextView n = tv(cells[0], 14, TXT, true);
                n.setPadding(dp(8), 0, 0, 0);
                n.setMaxLines(1);
                n.setEllipsize(TextUtils.TruncateAt.END);
                nb.addView(n);
                r.addView(nb, new LinearLayout.LayoutParams(0, -2, 2.3f));
                continue;
            }
            int col = head ? MUT : (i == 3 ? 0xFF1D4ED8 : i == 4 ? RED : TXT);
            TextView c = tv(cells[i], head ? 12 : 15, col, true);
            c.setGravity(i == 0 ? Gravity.START : Gravity.CENTER);
            r.addView(c, new LinearLayout.LayoutParams(0, -2, i == 0 ? 2.3f : 1f));
        }
        return r;
    }

    static class Donut extends View {
        final float[] v;
        final int[] c;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Donut(Context x, float[] v, int[] c) {
            super(x);
            this.v = v;
            this.c = c;
            p.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float tot = 0;
            for (float f : v) tot += f;
            float s = Math.min(getWidth(), getHeight());
            float sw = s * 0.2f;
            p.setStrokeWidth(sw);
            RectF r = new RectF(sw / 2, sw / 2, s - sw / 2, s - sw / 2);
            if (tot == 0) { p.setColor(0xFFE1E7EF); cv.drawArc(r, 0, 360, false, p); return; }
            float a = -90;
            for (int i = 0; i < v.length; i++) {
                float sweep = v[i] / tot * 360f;
                p.setColor(c[i]);
                cv.drawArc(r, a, sweep, false, p);
                a += sweep;
            }
        }
    }

    // ============================ Exportar ============================
    void export() {
        setHeader("Exportar a Excel", null, null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView ic = tv("📊", 48, TXT, false);
        ic.setGravity(Gravity.CENTER);
        c.addView(ic);
        TextView t = tv("Exportar a Excel", 20, TXT, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        TextView d = tv("Se genera un archivo con todas las citas del período: cliente, propiedad, precio, vendedores, estado, notas y seguimientos. Se abre directo en Excel o Google Sheets.", 14, MUT, false);
        d.setGravity(Gravity.CENTER);
        d.setPadding(0, dp(6), 0, 0);
        c.addView(d);
        p.addView(c);
        p.addView(rangeCard(expFrom, expTo, iso -> { expFrom = iso; export(); }, iso -> { expTo = iso; export(); }));
        final List<JSONObject> in = inRange(expFrom, expTo);
        TextView n = tv(in.size() + " citas en este período", 15, TXT, true);
        n.setPadding(dp(18), dp(10), dp(18), 0);
        p.addView(n);
        p.addView(button("📤  Exportar", GRN, v -> {
            if (in.isEmpty()) { toast("No hay citas en este período"); return; }
            pendingCsv = buildCsv(in);
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("text/csv");
            i.putExtra(Intent.EXTRA_TITLE, "citas_" + expFrom + "_a_" + expTo + ".csv");
            try { startActivityForResult(i, REQ_EXPORT); } catch (Exception e) { toast("No se pudo abrir el selector de archivos"); }
        }));
        show(scroll(p), false, false);
    }

    String buildCsv(List<JSONObject> list) {
        sortAsc(list);
        StringBuilder sb = new StringBuilder("\uFEFF");
        sb.append("Fecha,Hora,Cliente,Teléfono,Dirección,Precio,Agendó,Atenderá,Estado,Notas,Seguimientos\r\n");
        for (JSONObject a : list) {
            StringBuilder fs = new StringBuilder();
            JSONArray fu = a.optJSONArray("followups");
            if (fu != null) for (int i = 0; i < fu.length(); i++) {
                JSONObject f = fu.optJSONObject(i);
                if (f == null) continue;
                if (fs.length() > 0) fs.append(" | ");
                fs.append(f.optString("date")).append(" ").append(Store.niceTime(f.optString("time")))
                        .append(f.optBoolean("done") ? " (hecho) " : " ").append(f.optString("notes"));
            }
            String[] cols = {a.optString("date"), Store.niceTime(a.optString("time")), a.optString("name"), a.optString("phone"),
                    a.optString("address"), a.optString("price"), a.optString("booked"), a.optString("attends"),
                    a.optString("status"), a.optString("notes"), fs.toString()};
            for (int i = 0; i < cols.length; i++) {
                if (i > 0) sb.append(',');
                sb.append('"').append(cols[i].replace("\"", "\"\"")).append('"');
            }
            sb.append("\r\n");
        }
        return sb.toString();
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent data) {
        super.onActivityResult(rq, rs, data);
        if (rq == REQ_EXPORT && rs == RESULT_OK && data != null && data.getData() != null && pendingCsv != null) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                os.write(pendingCsv.getBytes(StandardCharsets.UTF_8));
                toast("Archivo guardado ✅");
            } catch (Exception e) {
                toast("No se pudo guardar el archivo");
            }
        }
    }

    // ============================ Más / Vendedores ============================
    void more() {
        setHeader("Más", null, "☰", false);
        LinearLayout p = vbox();
        LinearLayout c = card();
        c.addView(menuRow("👥", "Vendedores", "Agregar o editar el equipo", v -> open(this::sellersScreen)));
        c.addView(divider());
        c.addView(menuRow("📤", "Exportar a Excel", "Descargar las citas en un archivo", v -> open(this::export)));
        c.addView(divider());
        c.addView(menuRow("ℹ️", "Acerca de", "Citas Amigo Renta · versión 2.0", null));
        p.addView(c);
        show(scroll(p), true, false);
    }

    View menuRow(String ic, String title, String sub, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(6), 0, dp(6));
        TextView i = tv(ic, 22, TXT, false);
        i.setPadding(0, 0, dp(14), 0);
        r.addView(i);
        LinearLayout t = vbox();
        t.addView(tv(title, 16, TXT, true));
        t.addView(tv(sub, 13, MUT, false));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (l != null) { r.addView(tv("›", 22, MUT, false)); r.setOnClickListener(l); }
        return r;
    }

    void sellersScreen() {
        setHeader("Vendedores", sellers.size() + " en el equipo", null, true);
        LinearLayout p = vbox();
        LinearLayout c = card();
        for (int i = 0; i < sellers.size(); i++) {
            final int k = i;
            JSONObject s = sellers.get(i);
            if (i > 0) c.addView(divider());
            LinearLayout r = hbox();
            r.setPadding(0, dp(4), 0, dp(4));
            r.addView(avatar(s.optString("name"), PAL[i % PAL.length], 40));
            LinearLayout t = vbox();
            t.setPadding(dp(12), 0, 0, 0);
            t.addView(tv(s.optString("name"), 16, TXT, true));
            if (!s.optString("phone").isEmpty()) t.addView(tv("📞 " + s.optString("phone"), 13, MUT, false));
            r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
            r.addView(tv("›", 22, MUT, false));
            r.setOnClickListener(v -> editSeller(k));
            c.addView(r);
        }
        if (sellers.isEmpty()) c.addView(tv("No hay vendedores", 14, MUT, false));
        p.addView(c);
        p.addView(button("＋  Agregar vendedor", PRI2, v -> editSeller(-1)));
        show(scroll(p), false, false);
    }

    void editSeller(int i) {
        final JSONObject s = i >= 0 ? sellers.get(i) : null;
        LinearLayout box = vbox();
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText n = input("Nombre", TXT_CAP);
        EditText ph = input("Teléfono (opcional)", InputType.TYPE_CLASS_PHONE);
        if (s != null) { n.setText(s.optString("name")); ph.setText(s.optString("phone")); }
        box.addView(n);
        box.addView(ph);
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle(s == null ? "Nuevo vendedor" : "Editar vendedor")
                .setView(box)
                .setPositiveButton("Guardar", (dlg, w) -> {
                    String nm = n.getText().toString().trim();
                    if (nm.isEmpty()) return;
                    if (s == null) {
                        JSONObject o = new JSONObject();
                        put(o, "name", nm);
                        put(o, "phone", ph.getText().toString().trim());
                        sellers.add(o);
                    } else {
                        String oldN = s.optString("name");
                        put(s, "name", nm);
                        put(s, "phone", ph.getText().toString().trim());
                        if (!oldN.equals(nm)) {
                            for (JSONObject a : appts) {
                                if (a.optString("booked").equals(oldN)) put(a, "booked", nm);
                                if (a.optString("attends").equals(oldN)) put(a, "attends", nm);
                            }
                            Store.saveAppts(this, appts);
                        }
                    }
                    Store.saveSellers(this, sellers);
                    sellersScreen();
                })
                .setNegativeButton("Cancelar", null);
        if (s != null) b.setNeutralButton("Eliminar", (dlg, w) -> {
            sellers.remove(s);
            Store.saveSellers(this, sellers);
            sellersScreen();
        });
        b.show();
    }

    // ============================ Utilidades de datos ============================
    JSONObject find(int id) {
        for (JSONObject a : appts) if (a.optInt("id") == id) return a;
        return null;
    }

    List<JSONObject> inRange(String from, String to) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject a : appts) {
            String d = a.optString("date");
            if (d.compareTo(from) >= 0 && d.compareTo(to) <= 0) r.add(a);
        }
        return r;
    }

    void sortAsc(List<JSONObject> l) {
        Collections.sort(l, (x, y) -> (x.optString("date") + " " + x.optString("time"))
                .compareTo(y.optString("date") + " " + y.optString("time")));
    }

    String[] sellerNames() {
        String[] r = new String[sellers.size()];
        for (int i = 0; i < r.length; i++) r[i] = sellers.get(i).optString("name");
        return r;
    }

    int colorFor(String name) {
        for (int i = 0; i < sellers.size(); i++)
            if (sellers.get(i).optString("name").equals(name)) return PAL[i % PAL.length];
        return PRI2;
    }

    String price(JSONObject a) {
        String p = a.optString("price").trim();
        if (p.isEmpty()) return "";
        return p.startsWith("$") ? p : "$" + p;
    }

    static void put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (Exception e) { }
    }

    void pickDate(String iso, Cb cb) {
        Calendar c = Calendar.getInstance();
        try { c.setTime(Store.f("yyyy-MM-dd").parse(iso)); } catch (Exception e) { }
        new DatePickerDialog(this, (dpk, y, m, d) -> cb.on(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void pickTime(String hm, Cb cb) {
        int h = 10, mi = 0;
        try { String[] x = hm.split(":"); h = Integer.parseInt(x[0]); mi = Integer.parseInt(x[1]); } catch (Exception e) { }
        new TimePickerDialog(this, (tp, hh, mm) -> cb.on(String.format(Locale.US, "%02d:%02d", hh, mm)), h, mi, false).show();
    }

    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // ============================ Componentes visuales ============================
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    GradientDrawable roundStroke(int color, float r, int stroke) {
        GradientDrawable g = round(color, r);
        g.setStroke(dp(1), stroke);
        return g;
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    LinearLayout card() {
        LinearLayout c = vbox();
        c.setBackground(round(Color.WHITE, 16));
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(6), dp(14), dp(6));
        c.setLayoutParams(lp);
        return c;
    }

    ScrollView scroll(LinearLayout inner) {
        ScrollView s = new ScrollView(this);
        s.setFillViewport(true);
        inner.setPadding(0, dp(6), 0, dp(100));
        s.addView(inner, new FrameLayout.LayoutParams(-1, -2));
        return s;
    }

    HorizontalScrollView hscroll(View v) {
        HorizontalScrollView h = new HorizontalScrollView(this);
        h.setHorizontalScrollBarEnabled(false);
        h.addView(v);
        return h;
    }

    View sectionTitle(String t, String link, View.OnClickListener l) {
        LinearLayout r = hbox();
        r.setPadding(dp(18), dp(16), dp(18), dp(6));
        r.addView(tv(t, 17, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        if (link != null) {
            TextView k = tv(link, 14, PRI2, true);
            k.setOnClickListener(l);
            r.addView(k);
        }
        return r;
    }

    View empty(String s) {
        TextView t = tv(s, 14, MUT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundStroke(Color.WHITE, 14, BRD));
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(4), dp(14), dp(4));
        t.setLayoutParams(lp);
        return t;
    }

    View divider() {
        View d = new View(this);
        d.setBackgroundColor(BRD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(10), 0, dp(10));
        d.setLayoutParams(lp);
        return d;
    }

    View gap(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    int[] stColors(String s) {
        switch (s) {
            case "Atendida": return new int[]{0xFF15803D, 0xFFE3F6E8};
            case "Rentada": return new int[]{0xFF1D4ED8, 0xFFE4ECFF};
            case "Cancelada": return new int[]{0xFFB91C1C, 0xFFFDE6E6};
            case "No asistió": return new int[]{0xFF4B5563, 0xFFEEF0F3};
            default: return new int[]{0xFFB45309, 0xFFFFF1DB};
        }
    }

    TextView pill(String s) {
        int[] c = stColors(s);
        TextView t = tv("● " + s, 11, c[0], true);
        t.setBackground(round(c[1], 20));
        t.setPadding(dp(10), dp(4), dp(10), dp(4));
        return t;
    }

    TextView chip(String text, boolean sel, View.OnClickListener l) {
        TextView t = tv(text, 14, TXT, true);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        styleChip(t, sel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        t.setLayoutParams(lp);
        t.setOnClickListener(l);
        return t;
    }

    void styleChip(TextView t, boolean sel) {
        t.setBackground(sel ? round(PRI2, 20) : roundStroke(Color.WHITE, 20, BRD));
        t.setTextColor(sel ? Color.WHITE : TXT);
    }

    TextView avatar(String n, int color, int size) {
        String ini = n == null || n.trim().isEmpty() ? "?" : n.trim().substring(0, 1).toUpperCase(Store.ES);
        TextView t = tv(ini, size / 2.4f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        t.setBackground(g);
        t.setLayoutParams(new LinearLayout.LayoutParams(dp(size), dp(size)));
        return t;
    }

    View action(String ic, String label, int fg, int bg, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(bg, 14));
        b.setPadding(dp(2), dp(12), dp(2), dp(10));
        TextView i = tv(ic, 20, fg, false);
        i.setGravity(Gravity.CENTER);
        TextView t = tv(label, 10, fg, true);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(1);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(i);
        b.addView(t);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    TextView button(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 16, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(color, 14));
        b.setPadding(dp(14), dp(15), dp(14), dp(15));
        b.setElevation(dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), dp(6));
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    TextView outline(String text, int color, View.OnClickListener l) {
        TextView b = tv(text, 15, color, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(roundStroke(Color.WHITE, 14, color));
        b.setPadding(dp(10), dp(13), dp(10), dp(13));
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout.LayoutParams fieldLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, 0);
        return lp;
    }

    EditText input(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFFA0A8B5);
        e.setTextColor(TXT);
        e.setTextSize(15);
        e.setInputType(type);
        if ((type & InputType.TYPE_TEXT_FLAG_MULTI_LINE) != 0) {
            e.setMinLines(2);
            e.setGravity(Gravity.TOP | Gravity.START);
        }
        e.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        e.setPadding(dp(12), dp(11), dp(12), dp(11));
        e.setLayoutParams(fieldLp());
        return e;
    }

    TextView field(String text) {
        TextView t = tv(text, 15, TXT, false);
        t.setBackground(roundStroke(0xFFF8FAFD, 10, BRD));
        t.setPadding(dp(12), dp(12), dp(12), dp(12));
        t.setLayoutParams(fieldLp());
        return t;
    }

    TextView picker(String[] opts, String cur) {
        String val = (cur == null || cur.isEmpty()) ? (opts.length > 0 ? opts[0] : "") : cur;
        final TextView t = field(val + "  ▾");
        t.setTag(val);
        t.setOnClickListener(v -> new AlertDialog.Builder(this).setItems(opts, (dlg, w) -> {
            t.setTag(opts[w]);
            t.setText(opts[w] + "  ▾");
        }).show());
        return t;
    }

    View label(String icon, String text, boolean req) {
        LinearLayout r = hbox();
        r.setPadding(0, dp(14), 0, 0);
        r.addView(tv(icon + "  " + text, 13, MUT, true));
        if (req) r.addView(tv(" *", 13, RED, true));
        return r;
    }

    View labeled(String text, View v) {
        LinearLayout b = vbox();
        TextView l = tv(text, 13, MUT, true);
        l.setPadding(0, dp(14), 0, 0);
        b.addView(l);
        b.addView(v);
        return b;
    }

    View twoCols(View a, View b) {
        LinearLayout r = hbox();
        r.setGravity(Gravity.TOP);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, -2, 1f);
        l1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, -2, 1f);
        l2.setMargins(dp(6), 0, 0, 0);
        r.addView(a, l1);
        r.addView(b, l2);
        return r;
    }

    View rangeCard(String from, String to, Cb onFrom, Cb onTo) {
        LinearLayout c = card();
        TextView f = field("📅  " + Store.shortDate(from) + " " + from.substring(0, 4));
        TextView t = field("📅  " + Store.shortDate(to) + " " + to.substring(0, 4));
        f.setOnClickListener(v -> pickDate(from, onFrom));
        t.setOnClickListener(v -> pickDate(to, onTo));
        c.addView(twoCols(labeled("Desde", f), labeled("Hasta", t)));
        return c;
    }
}
