package com.citasamigorenta.app;
import android.app.*; import android.content.*; import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
  String name=i.getStringExtra("name"); String address=i.getStringExtra("address");
  String channel="citas"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"Citas Amigo Renta",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle("Recordatorio de cita").setContentText(name+" — "+address).setAutoCancel(true);
  nm.notify((int)System.currentTimeMillis(),b.build());
 }
}
